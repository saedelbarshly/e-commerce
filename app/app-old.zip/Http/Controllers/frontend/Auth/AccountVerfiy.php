<?php

namespace App\Http\Controllers\frontend\Auth;


use App\http\Controllers\Controller;
use App\Http\Controllers\Utils\MoraSmsProvider;
use App\Models\User;
use App\Repositories\Cart\CartRepository;
use Illuminate\Http\Request;

class AccountVerfiy extends Controller
{
  protected $cart;
  public function __construct(CartRepository $cart)
  {
    $this->cart = $cart;
  }
  public function showVerfiyForm()
  {
    $cartItems = $this->cart->get();
    $cartTotal = $this->cart->total();

    $user = User::orderBy('id', 'desc')->latest()->first();
    return view("frontend.auth.index",[
      'title' => trans("common.VerfiyAccount"),
      'breadcrumbs' => [
        [
          'url' => '',
          'text' => trans("common.VerfiyAccount"),
        ]
      ]
    ], compact('cartItems', 'cartTotal', 'user'));
  }

  public function verfiy(Request $request)
  {
    $this->validate($request, ['otp' => 'required|digits:6']);
    return $request->user;
    if ($user = User::where("otp", $request->otp)->first()) {
      $user->update([
        'block' => 0,
        'active' => 1,
        'verifyCode' => 1,
      ]);

      MoraSmsProvider::sendSms($user['phone'], trans('app.otp_code_sms' . $user['otp']));
      return redirect()->route("user.login")->with("success", trans("app.verfiy"));
    }

    return back()->with("error", trans("app.otp_not_valid"));
  }

  public function resentCode(Request $request)
  {

    $otp = otp_genrator();

    if ($user = User::where("id", $request->id)->first()) {
      $user->update(['otp' => $otp]);

      MoraSmsProvider::sendSms($user['phone'], trans('app.otp_code_sms' . $user['otp']));

      return redirect()->back()->with("success", trans("app.resentverfiy"));
    }

    return back()->with("error", trans("app.otp_not_valid"));
  }
}
