<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Cart;
use App\Repositories\Cart\CartModelRepository;
use App\Repositories\Cart\CartRepository;
use Illuminate\Http\Request;
use Termwind\Components\Dd;
use DB;


class CartController extends Controller
{
  protected $cart;
  public function __construct(CartRepository $cart)
  {
    $this->cart = $cart;
  }
  public function index()
  {
    $lang  = app()->getLocale();
    $cartItems = $this->cart->get();
    $cartTotal = $this->cart->total();
    if ($cartItems->count() == 0) {
      return redirect()->route('e-commerce.index');
    }

    return view('frontend.cart.index', [
      'title' => trans('common.cart'),
      'breadcrumbs' => [
        [
          'url' => '',
          'text' => trans('common.cart')
        ]
      ]
    ], compact('lang', 'cartItems', 'cartTotal'));
  }
  public function store(Request $request)
  {
    $request->validate([
      'product_id' => 'required|exists:products,id',
      'quantity' => 'nullable|numeric|min:1',
      'price' => 'required|numeric|min:1',
      'option' => 'nullable',
      'optionFile' => 'nullable',
    ]);
    $imagePath = '';
    if ($request->hasFile('optionFile')) {
      $image = $request->file('optionFile');
      $name = uniqid() . \Str::random(45) . '.' . $image->getClientOriginalExtension();
      $image->move(public_path('/uploads/cart'), $name);
      $imagePath = '/uploads/cart/' . $name;
    }
    $options = isset($request->option) ? base64_encode(serialize($request->option)) : '';
    $product = Product::findOrFail($request->product_id);
    $this->cart->add($product, $request->quantity ?? 1, $request->price, $options, $imagePath);
    return redirect()->back();
  }

  public function update(Request $request, $id)
  {
    $request->validate([
      'product_id' => 'required|exists:products,id',
      'quantity' => 'nullable|numeric|min:1',
      'price' => 'required|numeric|min:1',
      'option' => 'nullable',
    ]);
    $product = Product::findOrFail($request->product_id);
    $options = isset($request->option) ? base64_encode(serialize($request->option)) : '';
    $this->cart->update($id, $request->quantity, $options);
  }

  public function clear()
  {
    $this->cart->clear();
    return redirect()->back();
  }

  public function delete($id)
  {
    $this->cart->delete($id);
    $cartItems = $this->cart->get();
    $cartCount = $cartItems->count();
    $cartTotal = $this->cart->total();

    return response()->json([
      'status', 200,
      'message' => 'product removed successfully',
      'cartCount' => $cartCount,
      'cartTotal' => $cartTotal,
    ]);
    // return redirect()->back();
  }
  public function cartAjax(Request $request)
  {
    $product = Product::findOrFail($request->product_id);
    $lang  = app()->getLocale();
    $cartItems = $this->cart->get();
    $cartCount = $cartItems->count();
    $options = isset($request->option) ? base64_encode(serialize($request->option)) : '';
    $imagePath = '';
    $cartTotal = $this->cart->total();
    $this->cart->add($product, 1, $request->price, $options, $imagePath);
    $cartContentList = view(
      'frontend.layouts.topbar.cartItems',
      compact('cartItems', 'cartCount', 'lang', 'cartTotal')
    )->render();


    return response()->json([
      'status', 200,
      'message' => 'add product successfully',
      'cartContentList' => $cartContentList,
      'cartCount' => $cartCount + 1,
      'cartTotal' => $cartTotal,

    ]);
  }

  // public function increment(Request $request, $id)
  // {
  //   $product = Product::find($request->product_id);
  //   $options = isset($request->option) ? base64_encode(serialize($request->option)) : '';
  //  // $cartincrement = $product->price;
  //   $this->cart->update($id, 'quantity + 1', $options);
  //   return response()->json(array(
  //     'status' => 200,
  //     'message' => " incremented ",
  //    // 'cartincrement' => $cartincrement,
  //   ));
  // }

  public function increment(Request $request, $id)
  {
    $product = Product::find($id);

    $cartItem = DB::table('carts')
    ->where('product_id', $id)
      ->update([
        'quantity' => DB::raw('quantity+1')
      ]);
    $cartItem = Cart::where('product_id', $id);
    $cartTotal = $this->cart->total();
    return response()->json(array(
      'status' => 200,
      'message' => " incremented ",
      'cartTotal' => $cartTotal,
    ));
  }

  public function decrement(Request $request, $id)
  {
    $product = Product::find($id);
    $cartItem = DB::table('carts')
    ->where('product_id', $id)
      ->update([
        'quantity' => DB::raw('quantity-1')
      ]);
    $cartItem = Cart::where('product_id', $id);
    $cartTotal = $this->cart->total();
    return response()->json(array(
      'status' => 200,
      'message' => " incremented ",
      'cartTotal' => $cartTotal,
    ));
  }

  // public function decrement(Request $request, $id)
  // {
  //   $product = Product::findOrFail($request->product_id);
  //   $options = isset($request->option) ? base64_encode(serialize($request->option)) : '';
  //   $this->cart->update($id, 'quantity' - 1, $options);
  // }
}


