<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use App\Models\orderAddress;
use App\Models\OrderItems;
use App\Models\Orders;
use App\Models\Product;
use App\Models\ShippingLocations;
use App\Repositories\Cart\CartRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\Intl\Countries;

class checkoutController extends Controller
{
    protected $cart;
    public function __construct(CartRepository $cart)
    {
      $this->cart = $cart;
    }
    public function index(){
    $lang = app()->getLocale();
    $countries = Countries::getNames($lang);
    $cartItems = $this->cart->get();
    $cartTotal = $this->cart->total();
    if($cartItems->count() == 0){
      return redirect()->route('e-commerce.index');
    }
    $ShippingLocations = ShippingLocations::with('items')->get();
      return view('frontend.checkout.index',[
        'title' => trans('common.checkOut'),
        'breadcrumbs' => [
          [
            'url' => '',
            'text' => trans('common.checkOut')
          ]
        ]
      ], compact('lang', 'countries', 'cartItems', 'cartTotal', 'ShippingLocations'));
    }

    public function store(Request $request){
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
            'city' => 'required',
            'country' => 'required',
            'address' => 'required',
            'postalCode' => 'required',
          ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $cartItems = $this->cart->get();
        $cartTotal = $this->cart->total();
        $dateTime = date('Y-m-d H:i:s');
        $shippingPrice = isset($request->shippingPrice) ? $request->shippingPrice : 0;
        $tax = isset($request->tax) ? $request->tax : 0;
        $shipping_address = isset($request->shipping_address) ? $request->shipping_address : '';
        $coupon = isset($request->coupon) ? $request->coupon : '';
        $discount = 0;
        if($coupon != ''){
          $checkCoupon = $this->cart->applyCoupon($coupon);
          if($checkCoupon['status'] == 1){
            $discount = $checkCoupon['discount'];
          }
        }
        DB::beginTransaction();
        try {
          $order = Orders::create([
            'user_id' => auth()->id(),
            'date_time' => $dateTime,
            'date_time_str' => strtotime($dateTime),
            'total' => $cartTotal,
            'shipping_price' => $shippingPrice,
            'tax' => $tax,
            'shipping_address' => $shipping_address,
            'coupun_code' => $coupon,
            'discount' => $discount,
            'net_total' => ($cartTotal + $shippingPrice) - $discount,
            'status' => 'draft'
          ]);
          foreach($cartItems  as $key => $value) {
            $productDetails = Product::find($value['product_id']);
            if ($productDetails != '') {
              $oldItem = OrderItems::where('user_id', auth()->id())
              ->where('order_id', $order->id)
                ->where('product_id', $value['product_id'])
                ->first();
              if ($oldItem == '') {
                $item = OrderItems::create([
                  'user_id' => auth()->id(),
                  'order_id' => $order->id,
                  'product_id' => $value['product_id'],
                  'product_name' => $productDetails['name_'.app()->getLocale()],
                  'price' => $value['price'],
                  'quantity' => $value['quantity'],
                  'total' => $value['total'],
                  'net_total' => (($value['total'] + $shippingPrice) - $discount),
                ]);
              } else {
                $item = OrderItems::find($oldItem['id']);
                $update = $item->update([
                  'quantity' => $value['quantity'] + $oldItem['quantity'],
                  'total' => $value['total'] + $oldItem['total'],
                  'net_total' => (($value['total'] + $oldItem['total']) + $shippingPrice),
                ]);
              }
            }
          }
          $userAddress = orderAddress::create([
            'user_id' => auth()->id(),
            'order_id' => $order->id,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'phone' => $request->phone,
            'city' => $request->city,
            'country' => $request->country,
            'address' => $request->address,
            'postalCode' => $request->postalCode,
            'type' => 'shipping'
          ]);
          if(!$userAddress){
            return redirect()->back();
          }
          $this->cart->clear();
          DB::commit();
          return redirect()->route('orders.success', ['order' => $order->id])->with('success', trans('common.checkOutSuccess'));
        }catch(CartException $e){
          DB::rollBack();
          return redirect()->back()->with('error', $e->getMessage());
        }
        return redirect()->route('e-commerce.index');
    }

    public function applyCoupon(Request $request)
    {
      // $request->validate([
      //   'coupon' => 'required|exists:coupons,coupon'
      // ]);
      $result = $this->cart->applyCoupon($request->coupon);
      if ($result['status'] == 1) {
          return response()->json([
              'status' => 1,
              'total' => round($result['discounted'], 2),
              'message' => trans('common.ValidCoupon'),
          ]);
      }
      return response()->json([
          'status' => 0,
          'total' => $this->cart->total(),
          'message' => trans('common.InvalidCoupon')
      ]);
    }
}
