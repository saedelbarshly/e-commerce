<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Wishlist;
use App\Repositories\Cart\CartRepository;
use Illuminate\Http\Request;

class wishlistController extends Controller
{
  protected $cart;
  public function __construct(CartRepository $cart)
  {
    $this->cart = $cart;
  }
  public function index()
  {
    $lang = app()->getLocale();
    $cartItems = $this->cart->get();
    $cartTotal = $this->cart->total();
    $wishlists = Wishlist::with('product')->where('user_id', auth()->user()->id)->get();
    return view('frontend.wishlist.index', [
      'title' => trans('common.wishlist'),
      'breadcrumbs' => [
        [
          'url' => '',
          'text' => trans('common.wishlist')
        ]
      ]
    ], compact('lang', 'wishlists', 'cartItems', 'cartTotal'));
  }
  public function addItem(Request $request)
  {
    $user = auth()->user();
    $request->validate([
      'product_id' => 'required|exists:products,id',
    ]);

    $product_id = $request->input('product_id');
    $wishlistItem = $user->wishlist()->where('product_id', $product_id)->first();
    if(!$wishlistItem){
        $item = Wishlist::create([
            'product_id' => $product_id,
            'user_id' => $user->id
        ]);
    }
    return redirect()->back();
  }
  public function delete(Wishlist $wishlist)
  {
    $wishlist->delete();
    return redirect()->back();
  }
}
