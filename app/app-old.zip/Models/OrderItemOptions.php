<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItemOptions extends Model
{
    //
    protected $guarded = [];
    protected $table = 'order_item_options';
}
