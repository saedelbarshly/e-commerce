<?php

namespace App\Models;

use App\Models\Orders;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Symfony\Component\Intl\Countries;

class orderAddress extends Model
{
    use HasFactory;
    protected $table = 'order_addresses';
    protected $fillable = [
        'user_id',
        'order_id',
        'first_name',
        'last_name',
        'email',
        'phone',
        'city',
        'country',
        'address',
        'postalCode',
        'type'
    ];
    public function order(){
        return $this->belongsTo(Orders::class, 'order_id');
    }
    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }
    public function countryData()
    {
      $country = '';
      $lang = app()->getLocale();
      $countries = Countries::getNames($lang);
      foreach ($countries as $key => $value) {
        if ($key == $this->country) {
          $country = $value;
        }
      }
      return $country;
    }
}
